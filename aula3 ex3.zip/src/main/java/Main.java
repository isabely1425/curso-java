//Defina a classe pessoa
class Pessoa{
  //atributos da classe
  String nome;
  int idade;
  
//Constructor para inicializar os atributos
public Pessoa(String nome, int idade){
  this.nome = nome;
  this.idade = idade;
}
  
//metado para exibir as informações de pessoa 
public void exibirInformacoes(){
  System.out.println("Nome: " + nome);
  System.out.println("Idade: " + idade);
}
  }
public Class Main{
  public static void main(String[] args){
    //Criar objetos Pessoa
    Pessoa pessoa1 = new Pessoa("João", 30);
    Pessoa pessoa2 = new Pessoa("Maria", 25);

    //Exibir informações das pessoas
    pessoa1.exibirInformacoes();
    pessoa2.exibirInformacoes();
  }
}
